#!/bin/sh

LD_LIBRARY_PATH=. ./2dgamii
